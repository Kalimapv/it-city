import React from 'react'
import Container from 'react-bootstrap/Container';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import NavDropdown from 'react-bootstrap/NavDropdown';

const Category = () => {
  return (
    <div> <Navbar collapseOnSelect expand="lg" bg="light" variant="light">
    <Container>
      
      <Navbar.Toggle aria-controls="responsive-navbar-nav" />
      <Navbar.Collapse id="responsive-navbar-nav">
        <Nav className="me-auto">
          <Nav.Link href="#accessories">ACCESSORIES</Nav.Link>
          <Nav.Link href="#computers">COMPUTERS</Nav.Link>
          <Nav.Link href="#mobiles">MOBILES</Nav.Link>
          <Nav.Link href="#tablets">TABLETS</Nav.Link>
          <Nav.Link href="#appliances">HOME APPLIANCES</Nav.Link>
          <Nav.Link href="#watches">WATCHES & PERFUMES</Nav.Link>
          <Nav.Link href="#travels">TRAVEL BAGS</Nav.Link>
          <Nav.Link href="#personal">PERSONAL CARE</Nav.Link>
          <Nav.Link href="#cameras">CAMERAS & DRONES</Nav.Link>
          <Nav.Link href="#gaming">GAMING</Nav.Link>

         
        </Nav>
       
      </Navbar.Collapse>
    </Container>
  </Navbar></div>
  )
}

export default Category