import React from 'react'
// import Carousel from '../Carousel/Carousel'
import Carousel from '../Carousel';
import LatestProduct from '../LatestProduct';
import Footer from '../Footer/Footer'
import Topbar from '../Topbar';

const Home = () => {
  return (
    <div>
        <Topbar />
        <Carousel />
        {/* <LatestProduct /> */}
        {/* <Footer /> */}
    </div>
  )
}

export default Home