import React from 'react'

const Login = () => {
  return (
    <div class="container mt-4">
        <h2>Login</h2>
  <div class="row">

    <div class="col">
      <div>
      <input class="mb-3 mt-4 w-100" type='text' placeholder='Enter Your Email' />
      </div>
      <div>
      <input class="w-100" type='text' placeholder='Enter Your Password' />
      </div>
      <button class='mt-4 w-100'>Login</button>
    </div>
  </div>
</div>
  )
}

export default Login