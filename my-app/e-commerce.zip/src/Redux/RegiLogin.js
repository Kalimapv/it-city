import React from 'react'
import Login from './Login'
import Register from './Register'

const RegiLogin = () => {
  return (
         <div class="container">
         <div class="row text-center">
           <div class="col">
            <Login />
           </div>
           <div class="col">
             <Register />
           </div>
         </div>
       </div>
  )
}

export default RegiLogin