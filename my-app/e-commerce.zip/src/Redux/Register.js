import React, { useState } from 'react'
import {Button, Col, Row, Container, FormGroup, FormControl } from 'react-bootstrap'
import {useNavigate} from 'react-router-dom';
import { registration } from './RegisterSlice';
// import {registration} from './RegisterSlice';
import { useDispatch } from 'react-redux';

const Register = () => {
  
const dispatch = useDispatch();
const [name,setName] = useState('');
console.log(name);
const [email,setEmail] = useState('');
console.log(email);
const [password,setPassword] = useState('');
console.log(password);

const navigate = useNavigate();

const handleSubmit = (e) => {
  e.preventDefault();
  dispatch(registration({name,email,password}));
  console.log({ name, email, password });
  
  }
  // navigate('/login')

  return (
    <div>
      <Container>
        <Row className='registration'>
    <Col xs={12} sm={6} md={6} lg={6}>
      <h1 className='fw-7 fs-15 text-center'>Register</h1>
      <form onSubmit={handleSubmit}>
        <FormGroup>
          <FormControl className='mt-4' type='text'  Placeholder='Enter the Name' value={name} onChange={(e) => setName(e.target.value)} />
        </FormGroup>

        <FormGroup>
          <FormControl className='mt-3' type='email'  Placeholder='Enter the Email' value={email} onChange={(e) => setEmail(e.target.value)} />
        </FormGroup>

        <FormGroup>
          <FormControl className='mt-3 w-100%' type='password'  Placeholder='Enter the Password' value={password} onChange={(e) => setPassword(e.target.value)} />
        </FormGroup>

      <div className='mt-4'>
        <Button>Register</Button>
      </div>
      </form>
    </Col>
        </Row>
          </Container>
        </div>
  )
}

export default Register