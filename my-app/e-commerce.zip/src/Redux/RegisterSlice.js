import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import { APIClient } from "../Urls/urls";

const userSlice = createSlice({
  name: 'user',
  initialState: {
    token: "",
    user: [],
    userdetails: [],
  },
  reducers: {
   
  },
  extraReducers: (builder) => {
    builder
      .addCase(registration.fulfilled, (state, action) => {
        state.token = action.payload;
        state.user = action.payload;

      })
      .addCase(registration.rejected, (state, action) => {

        console.log('rejected');
      })
     
     
  }
});
export const registration = createAsyncThunk(
  'registration/registerUser',
  async (userData) => {
    try {
      const response = await APIClient.post('/register', userData);
      return response.data.data;
    } catch (error) {
      if (!error.response) {
        throw error;
      }
    }
  }
); 

export const getUser = (state) => state.user.user;

export default userSlice.reducer;


