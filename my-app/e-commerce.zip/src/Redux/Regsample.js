import React from 'react'
import axios from 'axios';
import { useState } from 'react';

function Regsample() {
         const [formData, setFormData] = useState({
                  name: '',
                  email: '',
                  // Add more fields as needed
                });
              
                // Update the form data state when inputs change
                const handleChange = (event) => {
                  setFormData({
                    ...formData,
                    [event.target.name]: event.target.value,
                  });
                };
              
                // Handle form submission
                const handleSubmit = (event) => {
                  event.preventDefault();
              
                  // Send the form data to the server using Axios
                  axios.post('https://itcity.tectuz.com/api/register', formData)
                    .then(response => {
                      console.log('Response:', response.data);
                      // Handle the response data here
                    })
                    .catch(error => {
                      console.error('Error:', error);
                      // Handle the error here
                    });
                };
              

  return (
    <div>   <form onSubmit={handleSubmit}>
    <input
      type="text"
      name="name"
      value={formData.name}
      onChange={handleChange}
      placeholder="Name"
    />

    <input
      type="email"
      name="email"
      value={formData.email}
      onChange={handleChange}
      placeholder="Email"
    />

    {/* Add more input fields as needed */}
    
    <button type="submit">Submit</button>
  </form></div>
  )
}

export default Regsample