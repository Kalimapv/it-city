


export const fetchAsyncarousel=createAsyncThunk(
    'carouselSlide/fetchAsyncarousel',
    async()=>{
        const response=await APIClient.get(`/findHomeImagesByEnglish`);
        const data= await response.data.data;
        return data;
    }
)