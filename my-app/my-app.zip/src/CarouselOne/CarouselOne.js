import React, { useState,useEffect } from 'react'
import OwlCarousel from 'react-owl-carousel';
import 'owl.carousel/dist/assets/owl.carousel.css';
import 'owl.carousel/dist/assets/owl.theme.default.css';
import axios from 'axios';

const baseURL = "https://itcity.tectuz.com/api/findHomeImagesByEnglish"
export const  imgURL="https://api.itcityonlinestore.com/uploads/home-slider/"

const CarouselOne = () => {
  const [post,setPost] = React.useState([])
  React.useEffect(() => {
    axios.get(baseURL).
    then((response) => {
      setPost(response.data.data);
      console.log(response.data.data)
      });  
  },[]);
  return (
   <div>  
      <OwlCarousel
          loop
          autoplay
          items={1}
          dots={true}
          margin={3}>
          
  {post.map((e,index)=>{
  return(
    <div>
  <img src={imgURL+e.img_name}></img>
  </div>
  )
      })
      }
  </OwlCarousel>
  </div>
  )
}
export default CarouselOne