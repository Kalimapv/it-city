import React from 'react'
import CarouselOne from '../CarouselOne/CarouselOne'
import LatestProduct from '../LatestProduct';
import Footer from '../Footer/Footer'

const Home = () => {
  return (
    <div>
        
        <CarouselOne />
        <LatestProduct />
        <Footer />
    </div>
  )
}

export default Home