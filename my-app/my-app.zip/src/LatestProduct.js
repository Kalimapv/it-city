import React, { useEffect } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { fetchAsynLatest, getLatestProduct } from './Redux/categorynavSlice';
import { Card,Button } from 'react-bootstrap';
import { thumbimgURL } from './Urls/urls';
import OwlCarousel from 'react-owl-carousel';
import 'owl.carousel/dist/assets/owl.carousel.css';
import 'owl.carousel/dist/assets/owl.theme.default.css';
import './LatestProduct.css';
import { Link } from 'react-router-dom';

const LatestProduct = () => {

const dispatch = useDispatch();
const LatestProduct = useSelector(getLatestProduct);
console.log("LatestProduct",LatestProduct)

    useEffect  (() => {
        dispatch(fetchAsynLatest(getLatestProduct))
    },[])

  return (
   
   <div>
    <h2>Latest Product</h2>
    <OwlCarousel
            loop
            items={5}
            margin={3}
            >
        {LatestProduct.map((val) => {
return(
  <div >
 
    <Card className='' style={{ width: '18rem' }}>
    <Link className='linkStyle' to = {`/product/${val?.id}`} key = {val?.id}>
      <Card.Img variant="top" src={thumbimgURL + val.product_image} />
        <Card.Body>
            <Card.Title>{val.product_name}</Card.Title>   
            <Card.Text className='offer_price' style={{textAlign:"center"}}>KWD {val.product_price_offer}</Card.Text>
            <Card.Text className='price' style={{textAlign:"center",textDecoration:"line-through"}}>KWD {val.product_price}</Card.Text>
       
      </Card.Body>
      <Button className='btn1' variant="primary">Add to Cart</Button>
      </Link>
    </Card>
   
    </div>
)
        })}
    </OwlCarousel>
   </div>

  )
}

export default LatestProduct