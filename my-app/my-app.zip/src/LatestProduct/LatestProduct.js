import React from 'react'
import './LatestPro.css'
import {Card,Button,Row,Col,Container} from 'react-bootstrap'
import axios from 'axios';

const baseURL = "https://itcity.tectuz.com/api/latestproduct?cur=KWD"

const thumbimgURL="https://api.itcityonlinestore.com/uploads/product/thumb_images/"

const LatestProduct = () => {
  const [latest,setLatest] = React.useState([])
  React.useEffect(() => {
    axios.get(baseURL).
    then((response) => {
      setLatest(response.data.data);
      console.log(response.data.data)
      });  
  },[]);

  return (
    <div className='main'>
    <h2 className='head'>Latest Product</h2>
    <div className='products'>
    {  latest.map((value,index)=>{
        return(
          <div className='main'>
            <Container>
              <Row>
                <Col md={4}>
              <Card className='MainCard' style={{ width: '18rem',height: '30rem' }}>                
              <Card.Img variant="top" src={thumbimgURL + value.product_image}
                style={{backgroundImage: `url(${thumbimgURL + value.backdrop_path})`, backgroundPosition:"center", backgroundSize:"cover",height:"286px"}}  >
              </Card.Img>
              <Card.Link href='#' className='brandName'>
                {value.product_name}
              </Card.Link>
              
                <Card.Link className='priceOffer'>KWD : {value.product_price_offer}
              </Card.Link>
              <Card.Text className='price'>
              KWD : {value.product_price}
              </Card.Text>
              <Button>Add to Cart</Button>
 
          </Card>
              </Col>
              </Row>
              </Container>
          </div>
        )
      })
    }
    </div>
    </div>
  );
}

export default LatestProduct