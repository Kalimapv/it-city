import React from 'react'
import axios from 'axios';
import OwlCarousel from 'react-owl-carousel';
import {Card,Button} from 'react-bootstrap'
import 'owl.carousel/dist/assets/owl.carousel.css';
import 'owl.carousel/dist/assets/owl.theme.default.css';
import './PopularProduct.css';

const baseURL = "https://itcity.tectuz.com/api/popularproduct?cur=KWD"
const thumbimgURL="https://api.itcityonlinestore.com/uploads/product/thumb_images/"

const PopularProduct = () => {

    const [latest,setLatest] = React.useState([])
    React.useEffect(() => {
      axios.get(baseURL).
      then((response) => {
        setLatest(response.data.data);
        console.log(response.data.data)
        });  
    },[]);

  return (
    <div>
        <OwlCarousel loop
                    dots={true}
                    items={5}
                    nav={true}>

                {latest.map((e,index) =>{
                    return(
            <div>
            <Card className='cardstyle' style={{width:'18rem',gap:'20'}}>
            <Card.Img variant="top" src={thumbimgURL + e.product_image}>
            </Card.Img>
            <Card.Link href='#'>{e.product_name}</Card.Link>                        
           
            <Card.Link className='priceOffer'>KWD : {e.product_price_offer}   </Card.Link>
            <Card.Text className='price'>
              KWD : {e.product_price}
              </Card.Text>
            <Button className='btn1'>Add to Cart</Button>
            </Card>
            </div>
               
            )
        })}
       
        </OwlCarousel>
    </div>

  )}
export default PopularProduct