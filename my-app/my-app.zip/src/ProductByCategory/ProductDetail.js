import React, { useEffect } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { useParams } from 'react-router-dom'
import { getProductCategory,fetchAsyncCategory } from '../Redux/categorynavSlice'
import { Link } from 'react-router-dom'
import  {Row,Col,Container, Card,Button}  from 'react-bootstrap'
import { thumbimgURL } from '../Urls/urls'
import './ProductDetail.css'

const ProductDetail = () => {

  const dispatch = useDispatch();
  const {category_id} = useParams();
  const Datas = useSelector(getProductCategory);
  console.log("Datas",Datas)
  
  useEffect(() => {
    dispatch(fetchAsyncCategory(category_id));
  },[dispatch,category_id])

  return (
  <div>
    <Container>
      <Row>
        <Col xs={1}>     
        FILTER        
        </Col>
        <Col xs={11} className='colu2'>
          {/* <div></div> */}
        {Datas.map((val,index)=> {
          return(
            <div>
            <Link className='linkStyle' to = {`/product/${val.product_id}`} key = {val?.id}>
            <Card style={{ width: '18rem' }}>
            <Card.Img variant="top" src={thumbimgURL + val.product_image} />
              <Card.Body>
                  <Card.Title>{val.product_name}</Card.Title>   
                  <Card.Text className='offer_price' style={{textAlign:"center"}}>KWD {val.product_price_offer}</Card.Text>
                  <Card.Text className='price' style={{textAlign:"center",textDecoration:"line-through"}}>KWD {val.product_price}</Card.Text>
                  <Button className='btn1' variant="primary">Add to Cart</Button>
            </Card.Body>

          </Card>
          </Link>
          </div>
          )
        })}

        </Col>  
      </Row>
    </Container>
  </div>
  )
}

export default ProductDetail
