import React, { useEffect,useState } from 'react'
import { Container,Row,Col, Card,Button } from 'react-bootstrap'
import { useDispatch, useSelector } from 'react-redux'
import { getProductBySingle,fetchAsyncSingle } from '../Redux/categorynavSlice'
import { useParams } from 'react-router-dom'
import { thumbimgURL,imgURL } from '../Urls/urls'
import { addToCart,getAllCarts } from '../Redux/cartSlice'



  const ProductBySingle = () => {
   
    const dispatch = useDispatch()
    const {product_id} = useParams();


    const [product_qty, setProduct_qty] = useState(1);




    const ProductSingle = useSelector(getProductBySingle)
    console.log('ProductSingle',ProductSingle)
    useEffect(() => {
        dispatch(fetchAsyncSingle(product_id))
    },[dispatch,product_id])

    const increaseQty = () => {
      setProduct_qty((prevQty) => {
        let tempQty = prevQty + 1;
        // if (tempQty > productdata?.stock) tempQty = productdata?.stock;
        return tempQty;
      })
    }
    const decreaseQty = () => {
      setProduct_qty((prevQty) => {
        let tempQty = prevQty - 1;
        // if (tempQty < 1) tempQty = 1;
        return tempQty;
      })
    }
    const addToCartHandler = (ProductSingle) => {
      let totalPrice = product_qty * ProductSingle?.product_price_offer;
      dispatch(addToCart({ ...ProductSingle, product_qty: product_qty, totalPrice: totalPrice }));
      
    }
  
   
  return (
    <div className='rows'>
  <Container>
  <Row>  
        
        {ProductSingle.map((val) => {
          return(
            <div>
              <Col sm={8}>
            <Card style={{ width: '22rem' }}>
              
                     <img src={thumbimgURL + val.product_image} />
                     <h4>{val.product_name}</h4>  
                      <h5>  Rs.{val.product_price_offer}</h5>

                      <div className='qty-change d-flex align-center '>
                            <h5>Quantity</h5>
                            <button type="button" className='qty qty-decrease flex align-center justify-center' onClick={decreaseQty} >
                              -
                            </button>
                            <div className=" qty-value flex align-center justify-center px-2 fw-bold">{product_qty} </div>
                            <button onClick={increaseQty} type="button" className='qty qty-increase flex align-center justify-center'  >
                              +
                            </button>
                          </div>
                      <Button className=' bg-dark border-0' onClick={() => {addToCartHandler(val)}} >Add To Cart</Button>
                          

            </Card>
              </Col>
                  
          </div>
            )
          })}
        
      
  </Row>

    </Container>
    </div>
  )
}

export default ProductBySingle