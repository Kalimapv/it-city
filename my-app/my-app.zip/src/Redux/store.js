import {configureStore} from '@reduxjs/toolkit'

import categoriesnavReducer from './categorynavSlice'

export const store=configureStore({
    reducer:{
        categoriesnav:categoriesnavReducer,
    }
})