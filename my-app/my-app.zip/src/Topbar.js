import { useDispatch, useSelector } from "react-redux";
import { useEffect } from "react";
import { fetchAsyncategories,getcategoriesNav } from "./Redux/categorynavSlice";
import Container from 'react-bootstrap/Container';
// import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import { Link } from "react-router-dom";
import './Topbar.css'
import { Nav } from "react-bootstrap";
import { getAllCarts } from "./Redux/cartSlice";

function Topbar(){

const dispatch=useDispatch()
const categories  = useSelector(getcategoriesNav);
console.log('categoeiesnav=',categories)

// const carts=useSelector(getAllCarts)
// console.log("carts",carts);

useEffect(()=>{
    dispatch(fetchAsyncategories(getcategoriesNav));
},[])
    return(
      <>
      <Navbar bg="dark" variant="light">
        <Container>
          <Nav>
        {categories.map((val,index) => {
          return( 
      <Link to={`/category/${val.cat_id}`} className='text-white text-decoration-none me-1' key={index}>{val.cat_name}</Link>                     
        )
         })}
         </Nav>
         </Container>
      </Navbar>    
      </>   
    )
}
export default Topbar;